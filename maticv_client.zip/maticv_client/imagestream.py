#!/usr/bin/env python
#-*- coding: GBK -*-

import os,re,sys
import subprocess
from common.adb import Adb

class Minicap(Adb):
    def __init__(self,window):
        super(Minicap,self).__init__()
        self.window = window    #��������0��������1��������
        self.width,self.height = self.get_width_and_height()

    #��ȡcpu�ͺ�
    def get_cpu(self):
        return self.shell("getprop ro.product.cpu.abi").strip()

    #��ȡϵͳ�汾
    def get_sdk(self):
        return self.shell("getprop ro.build.version.sdk").strip()

    #��ȡ��Ļ�ߴ�
    def get_mobile_size(self):
        stdout = self.shell("wm size").strip()
        pattern = re.compile(r"\d+")
        return pattern.findall(stdout)

    #���ݺ�������ȡ���Ⱥ͸߶�
    def get_width_and_height(self):
        w,h = self.get_mobile_size()
        if self.window:
            width = h
            height = w
        else:
            width = w
            height = h
        return width,height

    #�ϴ��ļ����ֻ�
    def push_file(self,local,remote):
        if os.path.exists(local):
            self.push(local,remote)
        else:
            raise "File under find! '%s'" % local


    #��minicap�Ŀ�ִ���ļ���.so�ļ�һ��push���豸��
    def push_minicap_bin_file(self):
        print "---push bin file---"
        abi = self.get_cpu()
        sdk = self.get_sdk()
        minicap = "build/bin/%s/minicap" % abi
        minicapNopie = "build/bin/%s/minicap-nopie" % abi
        minicapSo = "build/shared/android-%s/%s/minicap.so" % (sdk,abi)
        remote = "/data/local/tmp"

        self.push_file(minicap,remote)
        self.push_file(minicapNopie,remote)
        self.push_file(minicapSo,remote)
        self.chmod_file(remote,"minicap")
        self.chmod_file(remote,"mimicap-nopie")
        self.chmod_file(remote,"minicap.so")
        

    #����Ȩ��
    def chmod_file(self,filepath,filename):
        self.shell("chmod 777 %s/%s" % (filepath,filename))


    #���Է���
    def test_server(self):
        result = 0
        minicap_cmd = "LD_LIBRARY_PATH=/data/local/tmp /data/local/tmp/minicap -P %sx%s@%sx%s/0 -t" % (self.width,self.height,self.width,self.height)
        minicapNopie_cmd = "LD_LIBRARY_PATH=/data/local/tmp /data/local/tmp/minicap-nopie -P %sx%s@%sx%s/0 -t" % (self.width,self.height,self.width,self.height)

        print "---test server 1---"
        stdout =self.shell(minicap_cmd)
        print stdout
        if stdout.strip()[-2:] == "OK":
            return 1

        print "---test server 2---"
        stdout = self.shell(minicapNopie_cmd)
        print stdout
        if stdout.strip()[-2:] == "OK":
            return 2

        return 0
        

    #��������
    def start_server(self,flag):
        cmd = ""
        if flag == 1:
            print "---server started---"
            cmd = "LD_LIBRARY_PATH=/data/local/tmp /data/local/tmp/minicap -P %sx%s@%sx%s/0" % (self.width,self.height,self.width,self.height)
        elif flag == 2:
            print "---server started---"
            cmd = "LD_LIBRARY_PATH=/data/local/tmp /data/local/tmp/minicap-nopie -P %sx%s@%sx%s/0" % (self.width,self.heigth,self.width,self.height)
        self.shell(cmd)

    #����
    def start(self):
        self.push_minicap_bin_file()
        flag = self.test_server()
        if flag:
            self.start_server(flag)
        else:
            print "This device is not supported!!!"







"""
try:
    window = int(sys.argv[1])
except:
    window = 0
if not window or window < 0 or window > 1:
    window = 0
"""

window = raw_input("�����ú�������0����,1����,Ĭ��0��:")
if window == "1":
    window = 1
else:
    window = 0
    
minicap = Minicap(window)    
minicap.start()
    



