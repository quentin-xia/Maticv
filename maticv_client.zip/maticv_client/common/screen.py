#!/usr/bin/env python
#-*- coding:utf-8 -*-
import os
import gl
from utils import Utils
from match import Match

import platform
if platform.system() is "Windows":
    try:
        import build.opencv.x32.cv2 as cv2
    except:
        import build.opencv.x64.cv2 as cv2
else:
    import build.opencv.linux.cv2 as cv2



class LoopError(Exception):pass
class SaveError(Exception):pass
class MatchSaveError(Exception):pass
class MatchLoopError(Exception):pass
class TargetLoopError(Exception):pass


# mobileW 手机屏幕宽度
# mobileH 手机屏幕高度
# screenW 电脑屏幕宽度，默认1280
# screenH 电脑屏幕高度，默认800
# window   手机横竖屏（0:竖屏,1:横屏）,默认竖屏

class Screen(Utils):
    def __init__(self,mobileW,mobileH,project,c,window=0,screenW=800,screenH=800):
        self.project = project
        self.drawing = False
        self.flag = True
        self.strX = -1
        self.strY = -1
        self.endX = -1
        self.endY = -1
        self.rate = 0
        self.image = None
        self.img = None
        self.mobileW = mobileW  #手机宽度
        self.mobileH = mobileH  #手机高度
        self.screenW = screenW  #显示器宽度
        self.screenH = screenH  #显示器高度
        self.window = window
        self.shot = []
        self.sPos = 0.7
        self.mPos = 1
        self.c = c
        super(Screen,self).__init__()
        
    #画红框
    def draw_rectangle(self,event,x,y,flags,param):
        #鼠标左键按下事件
        if event == cv2.EVENT_LBUTTONDOWN:
            self.drawing = True
            self.strX = x
            self.strY = y
            self.endX = x
            self.endY = y
        #鼠标滑动和左键拖拽事件
        elif event == cv2.EVENT_MOUSEMOVE and flags == cv2.EVENT_FLAG_LBUTTON:
            if self.drawing == True:
                self.endX = x
                self.endY = y
        #鼠标左键抬起事件，并且两个点不重叠
        elif event == cv2.EVENT_LBUTTONUP and not (self.strX == self.endX or self.strY == self.endY):
            self.shot = []
            self.drawing = False
            self.flag = False
            #还原2个点的坐标
            x1,y1,x2,y2 = self.get_rectangle_point(self.strX,self.strY,self.endX,self.endY,self.rate)

            #截图
            self.shot = self.img[y1:y2,x1:x2]
            if self.window:
                #----
                angle = 4 - self.window
                self.shot = self.rotate_about_center(self.shot,angle)

    #画点
    def draw_circle(self,event,x,y,flags,param):
        if event == cv2.EVENT_LBUTTONUP:
            self.endX = x
            self.endY = y

    #trackbar
    def bar(self,pos):
        self.sPos = cv2.getTrackbarPos("Similar(1-100)%:","Matches") / 100.0
        self.mPos = cv2.getTrackbarPos("Matches(1-10):","Matches") + 1
    
    def draw(self,windowName,res):
        flag = True
        shot = self.shot.copy()
        image = self.image.copy()
        h,w = shot.shape[:-1]
        for point in res:
            try:
                if len(point) == 4:
                    x1,y1,x2,y2 = point
                    if flag:
                        color = gl.color[0]
                        flag = False
                    else:
                        color = gl.color[1]
                else:
                    x1,y1 = point
                    if x1 < 0 or y1 < 0:
                        continue
                    x2,y2 = x1 + w,y1 + h
                    color = gl.color[2]
                if x2 >= self.mobileW or y2 >= self.mobileH:
                    continue
                cv2.rectangle(shot,(0,0),(w,h),color[0],-1) 
                cv2.rectangle(image,(x1,y1),(x2,y2),color[0],1)
                roi = image[y1:y2,x1:x2]
                cv2.addWeighted(roi,color[1],shot,color[2],0,roi)
            except:
                continue
        if self.rate:
            image = self.zoom(image,self.rate)
        if self.window:
            #----
            image = self.rotate_about_center(image,self.window)
        cv2.imshow(windowName,image)
        return image,h,w

    #获取缩放比例
    def shrink(self):
        gapW = self.mobileW - self.screenW + 150
        gapH = self.mobileH - self.screenH + 150
        if gapW > 0 or gapH > 0:
            if gapW > gapH:
                self.rate = 1 - float("%.2f" % (float(gapW)/self.mobileW))
            else:
                self.rate = 1 - float("%.2f" % (float(gapH)/self.mobileH))
            #----
        else:
            self.rate = 0


    #截图流程
    def screen_img(self):
        try:
            self.screenshot()
            cv2.namedWindow("Screen")
            cv2.setMouseCallback("Screen",self.draw_rectangle)
            self.image = cv2.imread(gl.TEMP_IMAGE_PATH,1)
            #设置手机分辨率
            self.mobileW = len(self.image[0])
            self.mobileH = len(self.image)
            #图片缩放比例
            self.shrink()
            self.img = self.image.copy()
            if self.window:
                #----
                self.img = self.rotate_about_center(self.img,self.window)
            if self.rate:
                imgTmp = self.zoom(self.img,self.rate)
            else:
                imgTmp = self.img
            a = 0
            while True:
                #选择区域
                img = imgTmp.copy()
                cv2.rectangle(img,(self.strX,self.strY),(self.endX,self.endY),(0,0,255),1)
                cv2.imshow("Screen",img)
                key = 0
                key = cv2.waitKey(1)
                if key == 27:   #ESC
                    self.shot = []
                    raise LoopError
                #图像匹配
                if not self.flag:
                    sPos = 0.7
                    mPos = 1
                    shot = cv2.cvtColor(self.shot,cv2.COLOR_BGR2GRAY)
                    image = cv2.cvtColor(self.image,cv2.COLOR_BGR2GRAY)
                    match = Match()
                    res = match.find_all(shot,image,sPos,mPos)
                    cv2.destroyWindow("Screen")
                    cv2.namedWindow("Matches")
                    self.draw("Matches",res)
                    cv2.createTrackbar("Similar:","Matches",0,99,self.bar)
                    cv2.setTrackbarPos("Similar:","Matches",70)
                    cv2.createTrackbar("Matches:","Matches",0,9,self.bar)
                    self.sPos = 0.7
                    self.mPos = 1
                    while True:
                        if self.sPos != sPos or self.mPos != mPos:
                            sPos = self.sPos
                            mPos = self.mPos
                            res = match.find_all(shot,image,sPos,mPos)
                            cv2.destroyWindow("Screen")
                            self.draw("Matches",res)
                        key = 0
                        key = cv2.waitKey(1)
                        if key == 27:   #ESC
                            self.shot = []
                            raise LoopError
                        elif key == 66:  #B
                            self.drawing = False
                            self.flag = True
                            self.strX = -1
                            self.strY = -1
                            self.endX = -1
                            self.endY = -1
                            self.sPos = 0.7
                            self.mPos = 1
                            cv2.destroyWindow("Matches")
                            cv2.namedWindow("Screen")
                            cv2.setMouseCallback("Screen",self.draw_rectangle)
                            break
                        #save
                        elif key == 13: # enter return
                            raise MatchSaveError
                        #点击位置
                        elif key == 78:  #N
                            if len(res) > 0:
                                cv2.destroyWindow("Matches")
                                cv2.namedWindow("Target Offset")
                                cv2.setMouseCallback("Target Offset",self.draw_circle)
                                resImage,h,w = self.draw("Target Offset",res[:1])
                                if len(res[0]) == 4:
                                    x1,y1,x2,y2 = res[0]
                                else:
                                    x1,y1 = res[0]
                                    x2,y2 = x1 + w,y1 + h
                                #----
                                centerX,centerY = self.get_circle_point(x1,y1,x2,y2,self.mobileW,self.mobileH,self.window)
                                self.strX = -1
                                self.strY = -1
                                self.endX = int(round(centerX * self.rate))
                                self.endY = int(round(centerY * self.rate))
                                
                                while True:
                                    resImageTemp = resImage.copy()
                                    cv2.circle(resImageTemp,(self.endX,self.endY),3,(0,0,255),-1)
                                    cv2.imshow("Target Offset",resImageTemp)
                                    key = cv2.waitKey(1)
                                    if key == 27:   #ESC
                                        self.shot = []
                                        raise LoopError
                                    elif key == 66: #B
                                        cv2.destroyWindow("Target Offset")
                                        cv2.namedWindow("Matches")
                                        self.draw("Matches",res)
                                        cv2.createTrackbar("Similar:","Matches",0,99,self.bar)
                                        cv2.setTrackbarPos("Similar:","Matches",int(sPos*100))
                                        cv2.createTrackbar("Matches:","Matches",0,9,self.bar)
                                        cv2.setTrackbarPos("Matches:","Matches",mPos-1)
                                        break
                                    elif key == 13: # enter return
                                        raise SaveError
        except LoopError:
            cv2.destroyAllWindows()
        except MatchSaveError:
            if self.shot != []:
                filePath = self.get_img_name(self.project)
                cv2.imwrite(filePath,self.shot)
                code = "Code_%s: Pattern(\"%s\")" % (self.c,filePath)
                if sPos != 0.7:
                    code += ".similar(%s)" % (sPos)
                print code
            cv2.destroyAllWindows()
        except SaveError:
            if self.shot != []:
                filePath = self.get_img_name(self.project)
                cv2.imwrite(filePath,self.shot)
                #获取横竖屏坐标偏离值
                if self.endX == int(round(centerX * self.rate)) and self.endY == int(round(centerY * self.rate)):
                    x,y = 0,0
                else:
                    #偏移值
                    x = self.reduction_point(self.endX,self.rate) - centerX
                    y = self.reduction_point(self.endY,self.rate) - centerY

                    """
                    #横屏偏离值
                    if self.window == 1:
                        x = centerY - self.reduction_point(self.endY,self.rate)
                        y = self.reduction_point(self.endX,self.rate) - centerX
                    elif self.window == 2:
                        x = centerX - self.reduction_point(self.endX,self.rate)
                        y = centerY - self.reduction_point(self.endY,self.rate)
                    elif self.window == 3:
                        x = self.reduction_point(self.endY,self.rate) - centerY
                        y = centerX - self.reduction_point(self.endX,self.rate) 
                    #竖屏偏离值
                    else:
                        x = self.reduction_point(self.endX,self.rate) - centerX
                        y = self.reduction_point(self.endY,self.rate) - centerY
                    """

                code = "Code_%s: Pattern(\"%s\")" % (self.c,filePath)
                if sPos != 0.7:
                    code += ".similar(%s)" % (sPos)
                if x != 0 or y != 0:
                    code += ".target_offset(%s,%s)" % (x,y)
                print code
            cv2.destroyAllWindows()
 
    def match_img(self,imagePath):
        try:
            sPos = 0.7
            mPos = 1
            self.screenshot()
            self.image = cv2.imread(gl.TEMP_IMAGE_PATH,1)
            self.shot = cv2.imread(imagePath,1)
            #设置手机分辨率
            self.mobileW = len(self.image[0])
            self.mobileH = len(self.image)
            #图片缩放比例
            self.shrink()
            image = cv2.cvtColor(self.image,cv2.COLOR_BGR2GRAY)
            shot = cv2.cvtColor(self.shot,cv2.COLOR_BGR2GRAY)
            match = Match()
            res = match.find_all(shot,image,sPos,mPos)
            cv2.destroyWindow("Screen")
            cv2.namedWindow("Matches")
            self.draw("Matches",res)
            cv2.createTrackbar("Similar","Matches",0,99,self.bar)
            cv2.setTrackbarPos("Similar","Matches",70)
            cv2.createTrackbar("Matches","Matches",0,9,self.bar)
            self.sPos = 0.7
            self.mPos = 1
            while True:
                if self.sPos != sPos or self.mPos != mPos:
                    sPos = self.sPos
                    mPos = self.mPos
                    res = match.find_all(shot,image,sPos,mPos)
                    cv2.destroyWindow("Screen")
                    self.draw("Matches",res)
                key = 0
                key = cv2.waitKey(1)
                if key == 27 or key == 13:   #ESC or enter
                    raise MatchLoopError
                elif key == 78: #N
                    if len(res) > 0:
                        if len(res[0]) == 4:
                            cv2.destroyWindow("Matches")
                            cv2.namedWindow("Target Offset")
                            cv2.setMouseCallback("Target Offset",self.draw_circle)
                            resImage,h,w = self.draw("Target Offset",res[:1])
                            if len(res[0]) == 4:
                                x1,y1,x2,y2 = res[0]
                            else:
                                x1,y1 = res[0]
                                x2,y2 = x1 + w,y1 + h
                            #----
                            centerX,centerY = self.get_circle_point(x1,y1,x2,y2,self.mobileW,self.mobileH,self.window)
                            self.strX = -1
                            self.strY = -1
                            self.endX = int(round(centerX * self.rate))
                            self.endY = int(round(centerY * self.rate))
                            while True:
                                resImageTemp = resImage.copy()
                                cv2.circle(resImageTemp,(self.endX,self.endY),3,(0,0,255),-1)
                                cv2.imshow("Target Offset",resImageTemp)
                                key = cv2.waitKey(1)
                                if key == 27 or key == 13:   #ESC or enter
                                    raise TargetLoopError
                                elif key == 66: #B
                                    cv2.destroyWindow("Target Offset")
                                    cv2.namedWindow("Matches")
                                    self.draw("Matches",res)
                                    cv2.createTrackbar("Similar","Matches",0,99,self.bar)
                                    cv2.setTrackbarPos("Similar","Matches",int(sPos*100))
                                    cv2.createTrackbar("Matches","Matches",0,9,self.bar)
                                    cv2.setTrackbarPos("Matches","Matches",mPos-1)
                                    break
        except MatchLoopError:
            code = "Code: Pattern(\"%s\")" % (imagePath)
            if sPos != 0.7:
                code += ".similar(%s)" % (sPos)
            print code
            cv2.destroyAllWindows()
        except TargetLoopError:
            #获取横竖屏坐标偏离值
            if self.endX == int(round(centerX * self.rate)) and self.endY == int(round(centerY * self.rate)):
                x,y = 0,0
            else:
                #偏移值
                x = self.reduction_point(self.endX,self.rate) - centerX
                y = self.reduction_point(self.endY,self.rate) - centerY

                """
                #横屏偏离值
                if self.window == 1:
                    x = centerY - self.reduction_point(self.endY,self.rate)
                    y = self.reduction_point(self.endX,self.rate) - centerX
                elif self.window == 2:
                    x = centerX - self.reduction_point(self.endX,self.rate)
                    y = centerY - self.reduction_point(self.endY,self.rate)
                elif self.window == 3:
                    x = self.reduction_point(self.endY,self.rate) - centerY
                    y = centerX - self.reduction_point(self.endX,self.rate) 
                #竖屏偏离值
                else:
                    x = self.reduction_point(self.endX,self.rate) - centerX
                    y = self.reduction_point(self.endY,self.rate) - centerY
                """

            code = "Code: Pattern(\"%s\")" % (imagePath)
            if sPos != 0.7:
                code += ".similar(%s)" % (sPos)
            if x != 0 or y != 0:
                code += ".target_offset(%s,%s)" % (x,y)
            print code
            cv2.destroyAllWindows()



