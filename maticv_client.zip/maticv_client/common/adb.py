#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os,sys,time,re
import platform
import subprocess
import gl



class Adb(object):
    def __init__(self):
        gl.ADB_CMD = self._get_sdk_binary_present("adb")

    def adb(self,cmd):
        cmd = cmd.strip()
        if not cmd:
            msg = "You need to pass in a command to adb()"
            raise Exception(msg)
        cmd = "%s %s" % (gl.ADB_CMD,cmd)
        #print cmd
        pipe = subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,shell=True)
        out = pipe.stdout.read()
        err = pipe.stderr.read()
        if err and err.find(" bytes in ") == -1:
            msg = err
            raise Exception(msg)
        else:
            if out.lower().find("error:") == -1:
                return out
            else:
                msg = out
                raise Exception(msg)

    def shell(self,cmd):
        cmd = "shell %s" % cmd
        return self.adb(cmd)

    def wait_for_device(self,deviceId = None,waitSec = 10):
        #self._restart_adb()
        sec = 0.75
        endAt = time.time() + waitSec

        def do_wait():
            if time.time() > endAt:
                msg = "Device did not become ready in %s secs; are sure it's powered on?" % waitSec
                raise Exception(msg)
            devices = self._get_connected_devices()
            if devices == []:
                time.sleep(sec)
                return do_wait()
            else:
                if not deviceId:
                    device = devices[0]["udid"]
                    self._set_device_id(device)
                    return device
                else:
                    for i in range(len(devices)):
                        if devices[i]["udid"] == deviceId:
                            self._set_device_id(deviceId)
                            return deviceId
                time.sleep(sec)
                return do_wait()
                
        dev = do_wait()
        return self._check_adb_connection_is_up(),dev

    def pull(self,remotePath,localPath):
        cmd = "pull %s %s" % (remotePath,localPath)
        self.adb(cmd)

    def push(self,localPath,remotePath):
        cmd = "push %s %s" % (localPath,remotePath)
        self.adb(cmd)

    #获取屏幕尺寸
    def get_screen_resolution(self):
        display = []
        pattern = re.compile(r"\d+")
        #----
        """
        if platform.system() is "Windows":
            cmd = "dumpsys display | findstr PhysicalDisplayInfo"
            cmd1 = "dumpsys window | findstr Display: | findstr init="
            cmd2 = "dumpsys display | findstr DisplayDeviceInfo"
        else:
            cmd = "dumpsys display | grep PhysicalDisplayInfo"
            cmd1 = "dumpsys window | grep Display: | grep init="
            cmd2 = "dumpsys display | grep DisplayDeviceInfo"
        stdout = self.shell(cmd)
        display = pattern.findall(stdout)
        if display == []:
            stdout = self.shell(cmd1)
            display = pattern.findall(stdout)
        if display == []:
            stdout = self.shell(cmd2)
            display = pattern.findall(stdout)
            if display:
                display = display[1:]
        """
        cmd = "wm size"
        stdout = self.shell(cmd)
        display = pattern.findall(stdout)
        if display == []:
            msg = "Can't get screen resolution"
            raise Exception(msg)
        return (int(display[0]),int(display[1]))

            
    #解锁屏幕
    def unlock_screen(self):
        if self._is_screen_locked():
            self._push_unlock()
            timeout = 10
            endAt = time.time() + timeout
            sec = 0.75
            def unlock_and_check():
                pkg = "io.matip.unlock"
                activity = ".Unlock"
                self.start_app(pkg,activity)
                if not self._is_screen_locked():
                    return True
                if time.time() > endAt:
                    msg = "Screen did not unlock"
                    raise Exception(msg)
                else:
                    time.sleep(sec)
                    unlock_and_check()
            unlock_and_check()

    #安装apk
    def install_apk(self,apk,replace=True):
        cmd = "install "
        if replace:
            cmd += "-r "
            cmd += apk
            stdout = self.adb(cmd)
            stdout = stdout.strip()
            if stdout.find("Success") != -1:
                return True
            else:
                msg = "App was not installed"
                raise Exception(msg)

    #启动APP
    def start_app(self,pkg,act,retry=True):
        if not pkg or not act:
            msg = "Parameter 'appPackage' and 'appActivity' is required for lunching application"
            raise Exception(msg)
        cmd = "am start -n %s/%s" % (pkg,act)
        
        try:
            stdout = self.shell(cmd)
        except Exception,ex:
            if retry:
                self.start_app(pkg,act,False)
            else:
                msg = ex
                raise Exception(msg)
        return True

    #获取当前界面应用的package和activity
    def get_focused_package_and_activity(self):
        package = ""
        activity = ""
        if platform.system() is "Windows":
            cmd = "dumpsys window windows | findstr name="
        else:
            cmd = "dumpsys window windows | grep name="
        searchRe = re.compile(r"[a-zA-Z0-9\.]+/.[a-zA-Z0-9\.]+")
        stdout = self.shell(cmd)
        foundMatch = searchRe.findall(stdout)
        if len(foundMatch) > 0:
            foundMatch = foundMatch[0].split("/")
            package = foundMatch[0]
            activity = foundMatch[1]
        return package,activity

    #private
    def _push_unlock(self):
        unlockPath = os.path.join(os.getcwd(),"build","unlock_apk","unlock.apk")
        self.install_apk(unlockPath)


    #是否锁屏
    def _is_screen_locked(self):
        screenLocked = None
        samsungNoteUnlocked = None
        gbScreenLocked = None
        cmd = "dumpsys window"
        stdout = self.shell(cmd)
        screenLockedRe = re.compile(r"mShowingLockscreen=\w+")
        screenLocked = screenLockedRe.findall(stdout)
        samsungNoteUnlockedRe = re.compile(r"mScreenOnFully=\w+")
        samsungNoteUnlocked = samsungNoteUnlockedRe.findall(stdout)
        gbScreenLockedRe = re.compile(r"mCurrentFocus.+Keyguard")
        gbScreenLocked = gbScreenLockedRe.findall(stdout)
        if screenLocked:
            if screenLocked[0].split("=")[1] == "false":
                return False
            else:
                return True
        elif gbScreenLocked:
            return True
        elif samsungNoteUnlocked:
            if samsungNoteUnlocked[0].split("=")[1] == "true":
                return False
            else:
                return True
        else:
            return False

    def _check_adb_connection_is_up(self):
        stdout = self.shell("echo 'ready'")
        if stdout.find("ready") == 0:
            return True
        else:
            msg = "ADB ping failed,return: %s" % stdout
            raise Exception(msg)

    def _set_device_id(self,deviceId):
        gl.ADB_CMD += " -s %s" % deviceId

    #重启adb
    def _restart_adb(self):
        def restart():
            self.adb("kill-server")
            self.adb("start-server")
        for i in range(3):
            try:
                restart()
                break
            except Exception,ex:
                if i < 3:
                    continue
                else:
                    msg = ex
                    raise Exception(msg)

    def _get_sdk_binary_present(self,binary):
        if platform.system() is "Windows":
            if binary[-4:].find(".exe") == -1:
                binary += ".exe"
        path = os.path.abspath(os.path.join(os.path.dirname(__file__),os.path.pardir,"build","platform-tools",binary))
        return path

    def _is_device_connected(self):
        devices = self._get_connected_devices()
        if devices == []:
            msg = "0 device(s) connected"
            raise Exception(msg)
        return devices

    def _get_connected_devices(self):
        stdout = self.adb("devices")
        devices = []
        stdout = stdout.split("\n")
        for line in stdout:
            if line.strip() and line.find("List of devices") == -1 and line.find("* daemon") == -1 and line.find("offline") == -1:
                lineinfo = line.split("\t")
                devices.append({"udid":lineinfo[0],"state":lineinfo[1]})
        return devices


