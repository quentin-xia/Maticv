#/usr/bin/env python
#-*- coding:utf-8 -*-
import math,os
import numpy as np
from common.adb import Adb
from common.screencap import MinicapStream
import tempfile
import hashlib
import gl

import platform
if platform.system() is "Windows":
    try:
        import build.opencv.x32.cv2 as cv2
    except:
        import build.opencv.x64.cv2 as cv2
else:
    import build.opencv.linux.cv2 as cv2
    

class Utils(Adb,MinicapStream):
    def __init__(self):
        pass
        #super(Utils,self).__init__()

    #旋转图片函数
    def rotate_about_center(self,src,angle=1,scale=1.0):
        if 0 < int(angle) < 5:
            angle = 90 * angle
        else:
            angle = 90
        w,h = src.shape[1::-1]
        rangle = np.deg2rad(angle)
        nw = (abs(np.sin(rangle)*h) + abs(np.cos(rangle)*w))*scale
        nh = (abs(np.cos(rangle)*h) + abs(np.sin(rangle)*w))*scale
        rot_mat = cv2.getRotationMatrix2D((nw*0.5, nh*0.5), angle, scale)
        rot_move = np.dot(rot_mat, np.array([(nw-w)*0.5, (nh-h)*0.5,0]))
        rot_mat[0,2] += rot_move[0]
        rot_mat[1,2] += rot_move[1]
        return cv2.warpAffine(src, rot_mat, (int(math.ceil(nw)), int(math.ceil(nh))), flags=cv2.INTER_LANCZOS4)

    #获取矩形坐标
    def get_rectangle_point(self,strX,strY,endX,endY,rate):
        if strX > endX:
            x1,x2 = endX,strX
        else:
            x1,x2 = strX,endX

        if strY > endY:
            y1,y2 = endY,strY
        else:
            y1,y2 = strY,endY

        if rate:
            x1 = self.reduction_point(x1,rate)
            x2 = self.reduction_point(x2,rate)
            y1 = self.reduction_point(y1,rate)
            y2 = self.reduction_point(y2,rate)
        return x1,y1,x2,y2

    #获取目标位置坐标
    def get_circle_point(self,strX,strY,endX,endY,width=0,height=0,window=0):
        centerX = int((endX - strX) / 2) + strX
        centerY = int((endY - strY) / 2) + strY
        if window:
            tmpX = centerX
            tmpY = centerY

            if window == 1:
                centerX = tmpY
                centerY = width - tmpX

            elif window == 2:
                centerX = width - tmpX
                centerY = height - tmpY
            
            elif window == 3:
                centerX = height - tmpY
                centerY = tmpX
        return centerX,centerY

    #根据比例还原坐标
    def reduction_point(self,point,rate):
        return int(round(point * (1 / float(rate))))

    #根据比例缩小图片
    def zoom(self,image,rate):
        return cv2.resize(image,None,fx=rate,fy=rate,interpolation=cv2.INTER_AREA)

    #生成文件名
    def get_img_name(self,project):
        return tempfile.mktemp(".png","%s_" % project,"projects/%s" % project)


    #截屏
    def screenshot(self):
        #self.shell("screencap -p /sdcard/screenshot.png")
        #self.pull("/sdcard/screenshot.png",gl.TEMP_IMAGE_PATH)
        screencap = MinicapStream()
        screencap.ReadImageStream(gl.TEMP_IMAGE_PATH)



